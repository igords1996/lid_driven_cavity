#include "./source.h"
#include <math.h>
void setDensity(point* points, double kh)
{
	for (int i = 0; i < NPTS-4*NPTS_boundaries; i++)
	{
		double density = 0;
		// double density = MASS * w_lucy(0, kh);
		//neighbours* point = nh[i].list;
		//for (int j = 0; j < (int)nh[i].nNeighbours; j++)
		for (int j = 0;j<NPTS-4*NPTS_boundaries;j++)
		{
			double dx = ((double)points[i].x - (double)points[j].x)/100.0;
			double dy = ((double)points[i].y - (double)points[j].y)/100.0;
			double distance = sqrt(dx * dx + dy * dy);
			if (distance < kh)
			{
				density += MASSE * w_lucy(distance, kh);
			}
			//point = point->next;
			
		}
		points[i].density = density;
		/*if (points[i].x / 100 < kh)
		{
			double d = points[i].x / 100;
			double alpha = acos(d / kh);
			double A = M_PI * (kh * kh) - (kh * kh) / 2 * (2 * alpha - sin(2 * alpha));
			points[i].density = density / A * (M_PI * (kh * kh));
		}
		else if ((100 - points[i].x) / 100 < kh)
		{
			double d = (100 - points[i].x) / 100;
			double alpha = acos(d / kh);
			double A = M_PI * (kh * kh) - (kh * kh) / 2 * (2 * alpha - sin(2 * alpha));
			points[i].density = density / A * (M_PI * (kh * kh));
		}
		else if (points[i].y / 100 < kh)
		{
			double d = points[i].y / 100;
			double alpha = acos(d / kh);
			double A = M_PI * (kh * kh) - (kh * kh) / 2 * (2 * alpha - sin(2 * alpha));
			points[i].density = density / A * (M_PI * (kh * kh));
		}
		else if ((100 - points[i].y) / 100 < kh)
		{
			double d = (100 - points[i].y) / 100;
			double alpha = acos(d / kh);
			double A = M_PI * (kh * kh) - (kh * kh) / 2 * (2 * alpha - sin(2 * alpha));
			points[i].density = density / A * (M_PI * (kh * kh));
			printf("%f \n", density);
		}
		else
		{
			points[i].density = density;
		}*/
	}
}
// DENSITY SET OK
void updateDensity(point* points, double kh, float New_rho[400])
{
	for (int i = 0; i < NPTS-4*NPTS_boundaries; i++)
	{
		double der_density = 0;
		//neighbours* point = nh[i].list;
		double vxi = (double)points[i].vx/100.0;
		double vyi = (double)points[i].vy/100.0;
		double speed_i = sqrt(vxi*vxi+vyi*vyi);
		for (int j = 0; j < NPTS; j++)
		{
			double dx = ((double)points[i].x - (double)points[j].x) / 100.0;
			double dy = ((double)points[i].y - (double)points[j].y) / 100.0;
			double distance = sqrt(dx * dx + dy * dy);
			if (distance < kh)
			{
				double vxj = (double)points[j].vx / 100.0;
				double vyj = (double)points[j].vy / 100.0;
				double speed_j = sqrt(vxj * vxj + vyj * vyj);				
				der_density += MASSE * (speed_i - speed_j) * grad_w_lucy(distance, kh);
			}		
		}
		points[i].density =points[i].density + dt * der_density;
		//Euler pour le moment
		// Maintenant qu'on a les Drho/dt pour chaque points, on peut faire �voluer la valeur valeur leapfrog ou autre.
		// Cette valeur peut ensuite �tre corrig�e avec la m�thode CSPM
	}
	/*
	// METHODE CSPM
	for (int i = 0; i < NPTS; i++)
	{
		double num = 1;
		double denom = 1 / New_rho[i]; 
		//neighbours* point = nh[i].list;
		for (int j = 0; j < NPTS; j++)
		{
			double dx = ((double)points[i].x - (double)points[j].x) / 100.0;
			double dy = ((double)points[i].y - (double)points[j].y) / 100.0;
			double distance = sqrt(dx * dx + dy * dy);
			if (distance < kh)
			{
				num += w_lucy(distance, kh);
				denom += w_lucy(distance, kh) / New_rho[j];
			}

		}
		points[i].density = num / denom;
	}*/
}
// OK pour la premi�re it�ration

void updatePressure(point* points)
{
	double rho_0=0; // kg/m^3
	for (int i = 0; i < NPTS-4*NPTS_boundaries; i++)
	{
		rho_0 += points[i].density;
	}
	rho_0 = rho_0 / NPTS;
	double B = 0.0101300; // bar
	double gamma = 7;
	for (int i = 0; i < NPTS; i++)
	{
		points[i].pressure = B * (pow(points[i].density / rho_0, gamma)-1);
		// doit �tre =0 si inferieur a 0?
	}
}

void updateVelocity(point* points, double kh, float vx[400], float vy[400])
{
	double kin_v = 0.0001;// kinematic viscosity m^2/s
	double g = - 0.005; // gravity m/s^2
	for (int i = 0; i < NPTS-4*NPTS_boundaries; i++)
	{
		double cut_off = 0.05;
		float dvx = 0;
		float dvy = g;//g
		for (int j = 0; j < NPTS-4*NPTS_boundaries; j++)
		{
			double dx = ((double)points[i].x - (double)points[j].x) / 100.0;
			double dy = ((double)points[i].y - (double)points[j].y) / 100.0;
			double distance = sqrt(dx * dx + dy * dy);
			if (distance < kh && i!=j)
			{
				// PRESSURE PART
				//dvx += MASSE * ((double)points[i].pressure / ((double)points[i].density * (double)points[i].density) + (double)points[j].pressure / ((double)points[j].density * (double)points[j].density)) * grad_w_lucy(distance, kh) * sqrt(dx * dx) / distance;
				//dvy += MASSE * ((double)points[i].pressure / ((double)points[i].density * (double)points[i].density) + (double)points[j].pressure / ((double)points[j].density * (double)points[j].density)) * grad_w_lucy(distance, kh) * sqrt(dy * dy) / distance;
				// VELOCITY PART
				dvx += 2 * kin_v * MASSE / (points[j].density) * ((double)points[i].vx - (double)points[j].vx) * grad_w_lucy1D(sqrt(dy*dy),distance, kh) /(sqrt(dy*dy)+0.0001);// *dx / (dx * dx);
				dvy += 2 * kin_v * MASSE / (points[j].density) * ((double)points[i].vy - (double)points[j].vy) * grad_w_lucy1D(sqrt(dx*dx),distance, kh) /(sqrt(dx*dx)+0.0001); //*dy / (dy * dy);
				if (distance < cut_off)
				{
					dvx += 0.01 * dx / distance * (pow(cut_off / distance, 12) - pow(cut_off / distance, 4)) / MASSE;
					dvy += 0.01 * dy / distance * (pow(cut_off / distance, 12) - pow(cut_off / distance, 4)) / MASSE;
				}
			}
		}
		vx[i] = points[i].vx + dvx * dt*100; // euler method
		vy[i] = points[i].vy + dvy * dt*100;
	}
	for (int i = 0; i < NPTS; i++)
	{
		
		points[i].vx = vx[i];
		points[i].vy = vy[i];
	}
}

void updatePosition(point* points)
{
	for (int i = 0; i < NPTS-4*NPTS_boundaries; i++)
	{
		points[i].x += points[i].vx * dt; //euler
		points[i].y += points[i].vy * dt;
		if (points[i].x > 95)
		{
			points[i].x = 95 - (points[i].x - 95);
			points[i].vx = - 0.8*points[i].vx;
			points[i].vy = - 1;
			if (points[i].x < -5)
			{
				points[i].x = i/2;
				points[i].vx = 0;
				points[i].vy = 0;
			}
		}
		else if (points[i].x < -5)
		{
			points[i].x = -5-(points[i].x+5);
			points[i].vx = -0.8*points[i].vx;
			points[i].vy = 1;
			if (points[i].x > 95)
			{
				points[i].x = i/2;
				points[i].vx = 0;
				points[i].vy = 0;
			}
		}
		if (points[i].y > 95)
		{
			points[i].y = 95 - (points[i].y - 95);
			points[i].vy = -0.8*points[i].vy;
			points[i].vx =  1;
			if (points[i].y < -5)
			{
				points[i].y = i/2;
				points[i].vx = 0;
				points[i].vy = 0;
			}

		}
		else if (points[i].y < -5)
		{
			points[i].y = -5 - (points[i].y + 5);
			points[i].vy = -0.8*points[i].vy;
			points[i].vx = - 1;
			if (points[i].y > 95)
			{
				points[i].y = i/2;
				points[i].vx = 0;
				points[i].vy = 0;
			}
		}
	}
}
